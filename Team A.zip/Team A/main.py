from history_of_Teacher import function1, function2   # importing fuction1,function2 from other files
from Backup_data import function3   # importing fuction3 from  Backup_data
from storing_data import function   # importing fuction from other files  storing_data
class Project:            # taking the class
        def __init__(self):
            print("Welcome to Hyderabad Public School") # printing the school name
            choose_option={'ADD_DATA': 1, 'TO_READ': 2,
                           'TO_UPDATE': 3, 'TO_DELETE/STORE': 4, } # providing the options to the user to select which one they want
            print(choose_option) #printing the options
            select_number = int(input('Choose any number from the above given data :'))# providing the input to the user to enter the option number
            if select_number == 1:  # written the condition when the user select  option number 1
                function()        # add the teacher details to the collection
            elif select_number == 2:  # written the condition when the user select  option number 2
                function1()         # displaying the particular teacher details in the collection
            elif select_number == 3:   # written the condition when the user select  option number 3
                function2()            # displaying the updated person particular details in the collection
            elif select_number == 4:   # written the condition when the user select  option number 3
                function3()            # deleting teacher details in the collection and stored in collection1
            else:
                print('Invalid input')
Project() #calling the class
















