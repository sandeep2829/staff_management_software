from pymongo import MongoClient        # importing pymongo

connection = MongoClient(host="localhost", port=27017)     # establishing the connetion to the mongodb

data_base = connection.Demo_project    #  conecting to Demo project(database)
collection = data_base.Staff_details   # connecting staff details collection in demo project(database)
collection1 = data_base.Deleted_data   # connecting Deleted_data collection in demo project(database)
def function1():         # using a fuction to  read operation
    reading_values = input("Enter the staff name: ") # provide the input to user which one  data want to get
    read = collection.find({"Name": reading_values}) # store the getting data in a variable
    for a in read:       # using   for loop to read the particular person data
        print(a)         # printing the teacher whole details

def function2():        # using a fuction to update  operation
    update_values = input("Enter the staff name(Ex-G.Prathap): ")  # providing the input to user which one  data want to update

    change_values = {'Age': 1, 'Gender': 2, 'Address': 3,
                     'Designation': 4, "Date_of_joining": 5, "Salary": 6, "Date_of_birth": 7,
                     "Previous_job_history": 8}   # providing the options to the user to select which one they want to update
    print(change_values)
    changing = int(input('Choose any number You want to Update :'))  # providing  the input to the user to choose a number from the change values

    if changing == 1:       # written a condition when the user select  option number 1
        c = input('enter the update age of the teacher :') # providing the input to the user to enter the name to update
        updating = collection.update_one({'Name':update_values}, {'$set': {'Age': c}})  # update the given changes provided by the user
        print(updating)
    elif changing == 2:     # written a condition when the user select  option number 2
        c = input('enter the update Gender of the teacher :')    # providing the input to the user to enter the age to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Gender': c}}) # update the given changes provided by the user
        print(updating)

    elif changing == 3:     # written a condition when the user select  option number 3
        c = input('enter the update Address of the teacher :')   # providing the input to the user to enter the address to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Address': c}}) # update the given changes provided by the user
        print(updating)
    elif changing == 4:     # written a condition when the user select  option number 4
        c = input('enter the update Designation of the teacher :')   # providing the input to the user to enter the Designation to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Designation': c}})  # update the given changes provided by the user
        print(updating)
    elif changing == 5:     # written a condition when the user select  option number 5
        c = input('enter the update Date_of_joining of the teacher(Ex-dd/mm/yyyy) :')   # providing the input to the user to enter the Date_of_joining to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Date_of_joining': c}})  # update the given changes provided by the user
        print(updating)
    elif changing == 6:    # written a condition when the user select  option number 6
        c = input('enter the update Salary of the teacher :')   # providing the input to the user to enter the Salary to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Salary': c}})   # update the given changes provided by the user
        print(updating)
    elif changing == 7:   # written a condition when the user select  option number 7
        c = input('enter the update Date_of_birth of the teacher(Ex-dd/mm/yyyy) :')  # providing the input to the user to enter the Date_of_birth to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Date_of_birth': c}})  # update the given changes provided by the user
        print(updating)
    elif changing == 8:   # written a condition when the user select  option number 8
        c = input('enter the update Previous_job_history of the teacher :')  # providing the input to the user to enter the Previous_job_history to update
        updating = collection.update_one({'Name': update_values}, {'$set': {'Previous_job_history': c}})  # update the given changes provided by the user
        print(updating)


